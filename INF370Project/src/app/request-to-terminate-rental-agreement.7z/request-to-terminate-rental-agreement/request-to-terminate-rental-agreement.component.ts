import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { TerminatedAgree } from '../terminated-agree';
import { FormBuilder, Validators } from '@angular/forms';
import { MyServiceService } from '../my-service.service';
import { TerminateRService } from '../terminate-r.service';
import { MakePaymentService } from '../make-payment.service';
import { Terminate } from '../terminate';

@Component({
  selector: 'app-request-to-terminate-rental-agreement',
  templateUrl: './request-to-terminate-rental-agreement.component.html',
  styleUrls: ['./request-to-terminate-rental-agreement.component.css']
})
export class RequestToTerminateRentalAgreementComponent implements OnInit {

  dataSaved = false;  
  terminatedForm: any;  
  allTerminated: Observable<TerminatedAgree[]>;  
  terminatedIdUpdate = null;  
  massage = null;  
  url="http://formspree.io/nhlanhlakhosa69@gmail.com";
  totalAmount = 0;
  allRentals:any; 
  searchForm: any; 
  AmountDue:any;
  selected:any;
  Terminate = new Terminate();
  
  constructor(private apiService:MakePaymentService,private formbuilderUpdate:FormBuilder) { }  
  
  ngOnInit()  :void {this.GetAllRentalAgreements1();
    this.terminatedForm = this.formbuilderUpdate.group({  
  
  
      RentalAgreementID: ['', [Validators.required]], 
      TerminationDate: ['', [Validators.required]],   
      TerminationReason: ['', [Validators.required]],   

    });
  }
    GetAllRentalAgreements1(){
      this.apiService.getRentalAgreement1(sessionStorage.getItem('clientID')).toPromise().then(data => {//ClientID
        this.allRentals = data; debugger;
        console.log(data);
        debugger;
      });
    }
    GetAmount(ReferenceNo:string){debugger;
      this.apiService.getAmount1(ReferenceNo).toPromise().then(data => {//ClientID
        this.AmountDue = data.toString(); debugger;
        
      });
    }
    public onOptionsSelected(event) {debugger;
      const value = event.target.value;
      this.selected = value;
      console.log(value);
   }

   OnSubmit(){
this.Terminate=this.terminatedForm.value; debugger;
this.apiService.sendTermination(this.Terminate).subscribe(data=>{
  debugger;
  //this.myBooking();
  
});


   }
    }
  
